const express = require('express');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.json());

const PORT = 3001;
let messages = [];
let messageId = 1;

// Endpoint pour envoyer un message
app.post('/messages', (req, res) => {
    const { sender, receiver, content } = req.body;
    const newMessage = {
        id: messageId++,
        sender,
        receiver,
        content,
        status: 'sent',
        timestamp: new Date()
    };
    messages.push(newMessage);
    res.status(201).json(newMessage);
});

// Endpoint pour recevoir les messages pour un utilisateur donné
app.get('/messages/:receiver', (req, res) => {
    const receiver = req.params.receiver;
    const userMessages = messages.filter(message => message.receiver === receiver);
    res.status(200).json(userMessages);
});

// Endpoint pour vérifier le statut d'un message
app.get('/messages/status/:id', (req, res) => {
    const messageId = parseInt(req.params.id, 10);
    const message = messages.find(msg => msg.id === messageId);
    if (message) {
        res.status(200).json({ status: message.status });
    } else {
        res.status(404).json({ error: 'Message non trouvé' });
    }
});

// Endpoint pour mettre à jour le statut d'un message
app.put('/messages/status/:id', (req, res) => {
    const messageId = parseInt(req.params.id, 10);
    const { status } = req.body;
    const message = messages.find(msg => msg.id === messageId);
    if (message) {
        message.status = status;
        res.status(200).json(message);
    } else {
        res.status(404).json({ error: 'Message non trouvé' });
    }
});

app.listen(PORT, () => {
    console.log(`Le serveur fonctionne sur le port ${PORT}`);
});